// - Demo
// Saisie de l'utilisateur
const prenom = prompt("Entrer votre prénom");
const nom = prompt("Entrer votre nom");

console.log(prenom);
console.log(nom);

// Création du texte de bienvenue
// (Utilisation de la Concatenation)

//  -> Operateur « + »
const msg1 = "Bienvenue " + prenom + " " + nom + "!";

//  -> Méthode « concat »
const msg2 = "Bienvenue ".concat(prenom).concat(" ").concat(nom).concat("!");

//  -> Template String (Necessite l'utilisation de back-tick)
const msg3 = `Bienvenue ${prenom} ${nom}!`; 

// On recup l'element HTML pour interagir avec
const welcome = document.getElementById("welcome");
console.log(welcome);

// Modification du DOM
welcome.innerHTML = msg3;


// - Le caractere d'echappement
// Permet de déactivation un symbole interpreter par le Javascript (' " \ ` $)
// Permet des caracteres spéciaux:
//  -> Saut de ligne   \n\r
//  -> Tabulation      \t
//  -> Backspace       \b     (Peu utilisé)

// On souhaite créer une chaine de charactere avec ' ou "
// qui contient : « Il y a "l'oiseau" sur "l'elephant" ! »
const phrase1 = "Il y a \"l'oiseau\" sur \"l'elephant\" !";
const phrase2 = 'Il y a "l\'oiseau" sur "l\'elephant" !';
const phrase3 = `Le symbole back-tick (\`) permet d'utiliser un tokken sous le forme de \${...}.`; 
//  -> Tips : Resté homogène dans votre choix de "quote"

// Le saut de ligne
const phrase4 = "Hello\n\rWorld";

// Une tabulation
const phrase5 = "Hello\tWorld";


// - Les méthodes des Strings

const demoHello = "Hello World";
// (L'index d'une chaine commence à 0 et va jusqu'a la taille -1)

// Obtenir l'index de la lettre ou un texte
//  => Attention à la case!
//  => Renvoi une valeur negative (-1) si la valeur n'est pas trouvé
const v1 = demoHello.indexOf("o");      // 4
const v2 = demoHello.lastIndexOf("o");  // 7
const v3 = demoHello.indexOf("World");  // 6

// Obtenir une lettre via son index
const v4 = demoHello.charAt(1);         // "e"
const v5 = demoHello[1]                 // Idem avec l'operateur d'acces
const v6 = demoHello.charCodeAt(1);     // 101 => Code ASCII

// Obtenir une lettre depuis son code ASCII
const v7 = String.fromCharCode(101)     // "e"

// Remplacer une partie d'une chaine de charactere
const urlBase = "https://api.irail.be/liveboard/?station=__city__&format=json&lang=fr"
const city = "bruxelles-nord";

const urlFinal = urlBase.replace("__city__", city);

// Transformation de la case
const v8 = demoHello.toUpperCase();     // "HELLO WORLD"
const v9 = demoHello.toLowerCase();     // "hello world"

// Extraire un partie d'une chaine
// (Le dernier index n'est pas comprit !)
const v10 = demoHello.substring(0, 5);  // "Hello"
const v11 = demoHello.slice(0, 5);      // "Hello"

// Découper la chaine sur base d'un symbole
// -> Generer un tableau de valeur
const v12 = demoHello.split(' ');   //["Hello", "World"]

const t = "Demo JS - String"
const v13 = t.split(' ');           // ["Demo", "JS", "-", "String"]
const v14 = t.split(' ', 2);        // ["Demo", "JS"]