// - Déclaration et initialisation
const nbEntier = 42;
const nbReel = 3.14;

// En JS => Un seul type "number"   (Pas Integer VS Double)
console.log(typeof(nbEntier));
console.log(typeof(nbReel));


// - Conversion de texte en nombre
//   (En cas d'echec, on obtient "NaN")
const saisie = prompt("Veuillez entre un nombre");

const convEntier = Number.parseInt(saisie);
const convReel = Number.parseFloat(saisie);

console.log(convEntier);
console.log(convReel);


// - Les opérateurs arithmétiques
const nb1 = 42;
const nb2 = 5;

const r1 = nb1 + nb2;
const r2 = nb1 - nb2;
const r3 = nb1 / nb2;  // Reel VS Entiere
const r4 = nb1 * nb2;
const r5 = nb1 % nb2;

// Raccourci d'ecriture
let val = 10;
val += 2;       // -> val = val + 2;

// - Post/Pre-incrementation  (-> val = val + 1)
let count = 0;

// Post-incr => Utilise "count" et ensuite il incremente
console.log(count++);   // 0   
console.log(count);     // 1

// Pre-incr  => Il increment et ensuite il utilise "count"
console.log(++count);   // 2
console.log(count);     // 2


// Risque d'utiliser les incr/decr dans un calcul "complexe"
let a = 5;
let b = 2;

let res = a++ + (--a + b++) * ++b;

//  a = 5 > 6 > 5
//  b = 2 > 3
// lecture    : 5 + (5 + 2) * 4
// resolution : 5 + 7 * 4
//              5 + 28
//              33

//  -> L'incrementation et la décrémentation se déroule lors de 
//     la lecture de la ligne (Sans resprecté les prioritées)


// Note : https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Operators/Operator_Precedence#tableau