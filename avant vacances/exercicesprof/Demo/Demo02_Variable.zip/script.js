// Une variable : 
//  - Stock une valeur (Affecter / Lire / ...)
//  - Possede un nom
//  - Possede un type (string, number, boolean, ...)
//  - Zone mémoire

// En Js en variable peut être de 2 nature : 
//  - Dynamique
//  - Fixe (Les constantes)

// Le langage JS a un typage dynamique
// -> Bonne pratique : Ne pas changer le type de donnée d'une variable

// La convention de langage pour nommer les variables c'est : camelCase
// - Faire des nom comprehensible
//   Evité -> cncat, vrexp, ....
// - Regle
//   • Pas de symbole (Exception : _ $)
//   • Peut contenir des chiffres, mais jamais commencer par un chiffre
//   • Evité les caracteres les accents ;)

// Les différentes nature de variables en JS : 
// • var   -> variable global.
//   A evité (Variable historique)  

// • let   -> variable local.
//   Depuis ES2015. Limité au scope, permet la réaffectation
let demo01 = 42;
demo01 = demo01 + 2;

// • const -> constante local.
//   Depuis ES2015. Limité au scope et en lecteur seul aprés l'initialisation.
const welcomeMsg = "Hello World";
//welcomeMsg = "test"; // => Ceci n'est pas autorisé !!!


// Tips : Scope -> Zone de code courrante, limité par les accolades en JS

// Exemple de probleme avec les variables de nature "var"
if(false) {
    let msg = "Hello";
    var demo = "World";
 }
// => Meme si le code n'est pas executer, la variable "demo" est déclaré ! :(


// Les types de variables
// La méthode "typeof" permet d'obtenir le type d'une variable

// - Numerique
const nb1 = 42;
const nb2 = 3.14;

// - Chaine de caractere
const msg1 = "Hello";
const msg2 = 'World';
const msg3 = `Super !`;

// - Booleen
const test1 = true;
const test2 = false;

// - Date (Warning => Les mois commence à 0 jusqu'à 11)
const today = new Date();
const date1 = new Date(2020, 1, 1);   // -> 1er Fevrier 2020
const date2 = new Date("2021/01/01"); // -> 1er Janvier 2021

// Affichage des types (Sous forme de chaine de caractere)
console.log(typeof(nb1));       // "number"
console.log(typeof(msg1));      // "string"
console.log(typeof(test1));     // "boolean"
console.log(typeof(today));     // "object"


// Les constantes prédéfinies

// - Undefined : Valeur qui ne correspond à aucun type
let val_undefined;  
console.log(val_undefined);         // undefined
console.log(typeof(val_undefined)); // "undefined"

// - Null      : Contenu "inconnue" de type objet
//               -> Symbolise l'absence de valeur
let val_null = null;
console.log(val_null);              // null
console.log(typeof(val_null));      // "object"


// - Infinity     : Valeur en dehors des plages des nombres
const val_infinity = 42 / 0;
console.log(val_infinity);              // Infinity
console.log(typeof(val_infinity));      // "number"


// - NaN          : Valeur de type number non valide
//                  -> Echec de conversion (string -> number)
//                  -> Echec d'un fonction mathématique
const val_nan_01 = Number.parseInt('Six');
const val_nan_02 = Math.sqrt(-1);

console.log(val_nan_01);                // NaN
console.log(typeof(val_nan_01));        // "number"

// => Attention, l'operateur "===" ne fonctionne pas sur « NaN »
//    Pour tester une valeur « NaN » vous devez utiliser « isNaN »

// Valeur NaN                       [Resultat: true]
isNaN(val_nan_01);
isNaN("Hello World");
isNaN(NaN);

// Valeur nombre valide (!= NaN)    [Resultat: false]
isNaN(42);
isNaN("13");
