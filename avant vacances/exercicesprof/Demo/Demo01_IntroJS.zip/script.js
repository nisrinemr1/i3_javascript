// Ceci est un commentaire
// TODO Faire la demo ;)

// Interaction avec la console du navigateur
console.log("Hello World");
console.info("Ceci est un message d'info");
console.warn("Message de type 'Warning' ");
console.error("Message de type 'Erreur' ");


// Interaction avec les popups du navigateur (Moins utilisé)
/*
alert("Boum !");

const r1 = prompt("Hello. Vous allez bien ?");
console.log(r1);    // -> Texte (String)

const r2 = confirm("Avez vous des questions ?");
console.log(r2);    // -> Valeur boolean
*/


// Interaction avec le DOM
// DOM -> Représentation sous forme d'objet de la page Web
//        Il est accessible via l'objet "document"
console.log(document);


// - Recuperer un element via son ID
const title1 = document.getElementById("title1");
console.log(title1);
console.log(typeof(title1)); // Object => Ensemble de valeur de la balise HTML

const titleAbsent = document.getElementById("titleToto");
console.log(titleAbsent); //-> null, car l'element n'a pas été trouvé ! 

const text3 = document.getElementById("text3");

// - Valeur récuperable sur un element HTML 
//### innerHTML
// Permet d'acceder au contenu HTML de la balise
// # Acces en lecture 
console.log("Contenu de la balise : " + title1.innerHTML);
// # Acces en ecriture
title1.innerHTML = "Manon !";
console.log("Contenu de la balise : " + title1.innerHTML);


//### innerText 
// Permet d'acceder au contenu texte de la balise
console.log("Contenu HTML  : " + text3.innerHTML);
console.log("Contenu TEXTE : " + text3.innerText);

//### id
console.log("L'id de mon element est " + title1.id);
console.log(" ");


const elem = document.getElementById("random_id");
console.log(elem);

//### class  (className VS classList)

// # className -> Permet de manipuler les classes d'une balise via une chaine de caractere.
console.log("Les classes de l'element 'elem' sont : " + elem.className);

// # Exemple de modification du className
elem.className = "title souligne"
elem.className = "souligne text"
elem.className = "pretty_color"

