// ### Operarteur Egalité ###
// ##########################

// Operateur double-egale VS triple-egale

// -> La double-egalité teste le contenu (sans prendre en compte
//    le type de donné).
//    Le JS effectue des conversion pour pouvoir réaliser l'egalité

//    Risque de "surprise" 
const t1 = (0 == "0");  // true
const t2 = (0 == []);   // true
const t3 = ([] == "0"); // false :o

//    Note : l'utilisation d'une double-egalité est a évité.


// -> La triple-egalité teste en premier le type de donnée.
//    Si les données sont du même type, elle teste le contenu.
const t4 = (0 === "0");          // false
const t5 = ("42" === (20 + 22)); // false
const t6 = ( 42  === (20 + 22)); // true (-> Même type de donnée);


// Operateur de différence

// -> Il existe l'equivalent negatif pour les 2 operateurs d'egalité (!= VS !==).
const t7 =  (42 !== (20+22));
const t8 = !(42 === (20+22));


//**************************************************************************/

// ### Operarteur comparaison ###
// ##############################

// Les operateurs de comparaison sont :  >  <  >=  <= 
// Ils fonctionne sur les nombres et sur les chaines de caractere

// -> Comparaison de 2 nombres
const c1 = 42 > 20;     // true


// -> Comparaison d'un nombre et d'une chaine de caractere
//    Conversion implicite du type string vers "number"
const c2 = 20 < "13";   // false
const c3 = 20 > "13";   // true

//    Si la conversion echoue, ca donne le resultat de la conversion est "NaN"
//    Du coups, la comparaison sera toujours fausse!
const c4 = 20 > "Six";  // false


// -> Comparaison de 2 chaines de caractere
const c5 = "Riri" > "Zaza";     // false
const c6 = "Riri" < "Zaza";     // true

//    Attention a la casse !
const c7 = "riri" > "Zaza";     // true

//    https://i.insider.com/561017dddd0895d85b8b45e8
//    Pour évité le probleme, n'hésité pas a utilise 
//    les méthodes "toLowerCase()" et "toUpperCase()"

//    Exemple
const text1 = "Zaza" // Donnée obtenu via un prompt par exemple;
const c8 = "riri" > text1.toLowerCase();


//**************************************************************************/

// ### Operarteur logique ###
// ##########################

// Combiner des resultats booleen (true/false)

// -> Negation (en JS: !)
//    Inverser le resultat

//   Exemple : Tester si la valeur n'est pas superieur à 10
const valeur1 = 42;
const l1 = !(valeur1 > 10); // false        // Equivalent à "valeur <= 10"


// -> ET  (en JS: &&)
//    Si les 2 valeurs booleens sont vrai, le resultat est vrai !

//   Exemple : Encoder une valeur entre 10 et 20
const valeur2 = 13;
const l2 = (valeur2 >= 10) && (valeur2 <= 20); // true


// -> OU  (en JS: ||)   [Ou inclusif]
//    Si au moins une des valeurs est vrai, le resultat est vrai !

//   Exemple : Encoder une valeur egale a 13 ou supperieur à 42
const valeur3 = 13;
const l3 = (valeur3 === 13) || (valeur3 > 42);  // true


//   Exemple : Encoder une valeur qui est soit multiple de 2 ou de 3
const valeur4 = 42;
const l4 = (valeur4 % 2 === 0)  ||  (valeur4 % 3 === 0);  // true