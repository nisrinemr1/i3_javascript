// ### Chaine de caractere

const monTexte = "Ma formation JavaScript à Interface 3 !";
// A l'aide du JS et de la chaine de caractere :

// - Obtenir la position de la premier lettre "i"
const res01 = monTexte.indexOf('i');

const exo01 = document.getElementById('exo01');
exo01.innerHTML = `La position vaut ${res01}`;


// - Obtenir la lettre à l'index 28
const res02 = monTexte.charAt(28);      // Alternative text[28]

const exo02 = document.getElementById('exo02');
exo02.innerHTML = `La lettre est « ${res02} » `;


// - Remplacer "JavaScript" par "PHP"
const res03 = monTexte.replace('JavaScript', 'PHP');

const exo03 = document.getElementById('exo03');
exo03.innerHTML = res03;


// - Obtenir l'index de la derniere lettre "a" 
const res04 = monTexte.lastIndexOf('a');

const exo04 = document.getElementById('exo04');
exo04.innerHTML = `La postion vaut ${res04}`;


// - (Bonus) Inverser la chaine de caractere ;)

// Découper la chaine sous forme de tableau
const textTab = monTexte.split('');

// Inverser le tableau 
const inverseTab = textTab.reverse();

// Fusionner le tableau en chaine de caractere
const textInverse = inverseTab.join('')

// Affichage de la réponse dans le DOM
const exo05 = document.getElementById('exo05');
exo05.innerHTML = textInverse;

/**********************************************************/
// ### Les numeriques

// Ecrire un algo qui permet à l'utilisateur d'encoder
// 2 nombres (via le prompt). Afficher sur la page

// - On effectue une saisie utiliser et une conversion
const saisieNb1 = prompt("Veuillez encoder le 1er nombre");
const saisieNb2 = prompt("Veuillez encoder le 2e nombre");

const nb1 = Number.parseFloat(saisieNb1);
const nb2 = Number.parseFloat(saisieNb2);

const elemNb1 = document.getElementById('nb1');
const elemNb2 = document.getElementById('nb2');
elemNb1.innerHTML = nb1;
elemNb2.innerHTML = nb2;


// les resultats suivants : 
//  - L'addition
const res06 = nb1 + nb2;

const exo06 = document.getElementById('exo06');
exo06.innerHTML = `Le resultat vaut ${res06}`; 


//  - La soustraction 
const res07 = nb1 - nb2;

const exo07 = document.getElementById('exo07');
exo07.innerHTML = `Le resultat vaut ${res07}`; 


//  - La division reel
const res08 = nb1 / nb2;

const exo08 = document.getElementById('exo08');
exo08.innerHTML = `Le resultat vaut ${res08}`; 


//  - La division entiere
//const res09 = Number.parseInt(nb1 / nb2);
const res09 = Math.floor(nb1 / nb2);

const exo09 = document.getElementById('exo09');
exo09.innerHTML = `Le resultat vaut ${res09}`; 

//  - Le reste de la division entiere
const res10 = nb1 % nb2;

const exo10 = document.getElementById('exo10');
exo10.innerHTML = `Le resultat vaut ${res10}`; 

//  - (Bonus) Si la somme des nombres est paire
const temp = nb1 + nb2;
//const res11 = Math.floor(temp / 2) * 2 == temp;
const res11 = temp % 2 == 0;

const exo11 = document.getElementById('exo11');
exo11.innerHTML = `Le resultat vaut ${res11}`; 