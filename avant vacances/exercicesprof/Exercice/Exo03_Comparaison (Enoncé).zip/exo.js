const a = 13;
const b = 22;
const c = 2;
const d = 42;
const e = 21;
const f = true;
const g = 26;
const h = 3.14;
const i = "42";
const k = "Six";
const name1 = "Riri";
const name2 = "Fifi";
const name3 = "Zaza";
const name4 = "Loulou";









const res01 = a > b;
const res02 = (a * c) < b;
const res03 = !(b > e);
const res04 = c > (b - e);
const res05 = (a * 2) >= g;
const res06 = f && (a <= b) && (d/2 === e);
const res07 = (h * 2) > 6;
const res08 = Math.floor(e / 2) > (g / a);
const res09 = (name1 > name2) && (name3 > name4);
const res10 = (name1 > "Donald") || (name4 > "Balthazar");
const res11 = (a > c) && !(e > g) && (a % 2 === 0) && !f;
const res12 = ((d === (e * 2)) || (e > g)) && (d === i);
const res13 = ((a * 2) > (g / 2)) || f || ((g + b + c > d) * h);
const res14 = k > 5;

// 15) Tester si une valeur est comprise entre 0 et 10

// 16) Tester si une valeur est positive mais différente de 42

// 17) Tester si une valeur texte est egale à "Donald" ou "Daisy"

// [Bonus] Tester si une valeur est un multiple de 5 ou 
// un mutiple de 3. Mais sans être un multiple des deux.