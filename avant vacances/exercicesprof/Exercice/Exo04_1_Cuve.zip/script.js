// Lecture de la saisie de l'utilisateur
const saisieUser = prompt('Veuillez encoder le niveau de la cuve (0 -> 50)');
const niveauCuve = Number.parseFloat(saisieUser);

// Recuperation des elements du DOM en JS
const msgAlert = document.getElementById('msgAlert');
const nvCuve = document.getElementById('nvCuve');

// Verifier si la donnée est valide
if(!isNaN(niveauCuve) && (niveauCuve >= 0) && (niveauCuve <= 50)) {
    // La valeur du niveau est valide avec une valeur de 0 à 50 !

    nvCuve.innerHTML = niveauCuve;

    // Gestion du message
    if(niveauCuve === 0) {
        msgAlert.innerHTML = 'La cuve est vide !';
    }
    else if(niveauCuve <= 10) {
        msgAlert.innerHTML = 'La cuve est presque vide';
    }
    else if(niveauCuve === 50) {
        msgAlert.innerHTML = 'La cuve est pleine';
    }
}
else {
    // La valeur du niveau est incorrect :(
    msgAlert.innerHTML = 'La valeur encodée est érroné !';
}
