console.log("Le fichier javascript est présent :)")

// On recup les elements de la page web via leurs id
const demo = document.getElementById("demo");
const btn = document.getElementById("btn");

console.log("Le JS a récuperer depuis la page : ");
console.log(demo);
console.log(btn);

/* On ajoute un comportement quand on clique sur le bouton */
btn.addEventListener("click", function() {
    // Le code ici se declanche quand on l'utilisateur clique
    console.log("L'utilisateur a cliqué !!!");

    // On modifie le text contenu dans la balise "<h1>Hello World</h1>"
    demo.innerText = "Hello JS !";
});
